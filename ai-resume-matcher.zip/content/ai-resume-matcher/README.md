# AI Resume Matcher

An AI-powered resume analysis tool that compares a candidate’s resume with a job description and provides:
- Match percentage
- Missing or underrepresented skills

Built using Natural Language Processing (NLP) and Machine Learning.

---

## Features
- Resume vs Job Description similarity scoring
- Skill gap identification
- Text preprocessing and cleaning
- Modular and reusable Python codebase
- Easy to extend for real-world hiring systems

---

## Tech Stack
- Python
- Scikit-learn
- NLP (TF-IDF Vectorization)
- Cosine Similarity
- NumPy
- Pandas

---

## Project Structure
ai-resume-matcher/
├── data/
├── src/
│   ├── preprocess.py
│   └── matcher.py
├── AI_Resume_Matcher.ipynb
├── requirements.txt
└── README.md

---

## How It Works
1. Resume and job description text are cleaned and normalized
2. TF-IDF vectorization converts text into numerical features
3. Cosine similarity calculates match percentage
4. Missing keywords are extracted to highlight skill gaps

---

## Usage Example

from matcher import match_resume

resume_text = "Python developer with machine learning experience"
job_description = "Looking for a machine learning engineer skilled in Python and NLP"

score, missing_skills = match_resume(resume_text, job_description)

print("Match Score:", score)
print("Missing Skills:", missing_skills)

---

## Author
Sreehari V Nair
BTech CSE (AI & ML)
Jain (Deemed-to-be University)