from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from preprocess import clean_text

def match_resume(resume_text, job_description):
    resume_clean = clean_text(resume_text)
    jd_clean = clean_text(job_description)

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform([resume_clean, jd_clean])

    similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
    match_percentage = round(similarity * 100, 2)

    feature_names = vectorizer.get_feature_names_out()
    resume_vec = tfidf_matrix.toarray()[0]
    jd_vec = tfidf_matrix.toarray()[1]

    missing_skills = [
        feature_names[i]
        for i in range(len(feature_names))
        if jd_vec[i] > 0.05 and resume_vec[i] == 0
    ]

    return match_percentage, missing_skills
